const KEY="meu_ponto_v1", SET="meu_ponto_settings";
const defaults={salary:2500,extraPct:50,divisor:220};
let data=JSON.parse(localStorage.getItem(KEY)||"{}"), settings={...defaults,...JSON.parse(localStorage.getItem(SET)||"{}")};
const $=id=>document.getElementById(id);
function dateKey(d=new Date()){return d.toISOString().slice(0,10)}
function fmtMin(m){m=Math.max(0,Math.round(m));let s=m<0?"-":"";return s+String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0")}
function parseTime(t){let [h,m]=t.split(":").map(Number);return h*60+m}
function today(){let k=dateKey(); if(!data[k]) data[k]={}; return data[k]}
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function nowTime(){return new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}
function minNow(){let d=new Date();return d.getHours()*60+d.getMinutes()+d.getSeconds()/60}
function dayInfo(k=dateKey()){
 let d=new Date(k+"T12:00:00"), dow=d.getDay(), t=data[k]||{};
 let end=dow===5?parseTime("16:30"):dow>=1&&dow<=4?parseTime("17:30"):0;
 let start=parseTime("07:30"), lunch=60;
 let target=end? (end-start-lunch):0;
 return {dow,start,end,target,lunch,t};
}
function intervals(t){
 let arr=[];
 if(t.entry && t.exit) arr.push([parseTime(t.entry),parseTime(t.exit)]);
 if(t.lunchStart&&t.lunchEnd) arr.push([parseTime(t.lunchStart),parseTime(t.lunchEnd)]);
 if(t.kidsStart&&t.kidsEnd) arr.push([parseTime(t.kidsStart),parseTime(t.kidsEnd)]);
 if(!t.entry) return [];
 let end=t.exit?parseTime(t.exit):minNow();
 let worked=end-parseTime(t.entry);
 if(t.lunchStart&&t.lunchEnd) worked-=parseTime(t.lunchEnd)-parseTime(t.lunchStart);
 if(t.kidsStart&&t.kidsEnd) worked-=parseTime(t.kidsEnd)-parseTime(t.kidsStart);
 return Math.max(0,worked);
}
function calc(k){
 let {target,t}=dayInfo(k), w=intervals(t), bal=w-target;
 return {w,target,extra:Math.max(0,bal),deficit:Math.max(0,-bal),bal};
}
function setStamp(field){
 let t=today(); t[field]=nowTime(); save(); render();
}
["entry","lunchStart","lunchEnd","kidsStart","kidsEnd","exit"].forEach(id=>$(id).onclick=()=>setStamp(id));
function render(){
 let now=new Date(); $("clock").textContent=now.toLocaleTimeString("pt-BR");
 $("date").textContent=now.toLocaleDateString("pt-BR",{weekday:"long",day:"2-digit",month:"long"});
 let k=dateKey(), c=calc(k), t=today();
 $("worked").textContent=fmtMin(c.w); $("extra").textContent=fmtMin(c.extra); $("balance").textContent=(c.bal>=0?"+":"-")+fmtMin(Math.abs(c.bal));
 const labels={entry:"Entrada",lunchStart:"Início almoço",lunchEnd:"Fim almoço",kidsStart:"Saída buscar filhos",kidsEnd:"Retorno",exit:"Saída"};
 $("todayRows").innerHTML=Object.entries(labels).map(([f,l])=>t[f]?`<div class="row"><span>${l}</span><b>${t[f]}</b></div>`:"").join("");
 let msg="Pronto para bater a entrada.";
 if(t.entry&&!t.exit) msg=`Jornada prevista: ${fmtMin(c.target)} • faltam ${fmtMin(Math.max(0,c.target-c.w))} para cumprir a jornada.`;
 if(t.exit) msg=c.extra?`Hoje você fez ${fmtMin(c.extra)} de hora extra.`:`Hoje ficou ${fmtMin(c.deficit)} abaixo da jornada.`;
 $("next").textContent=msg;
 renderHistory(); renderMoney();
}
function renderHistory(){
 let keys=Object.keys(data).sort().reverse();
 $("historyList").innerHTML=keys.length?keys.map(k=>{let c=calc(k),d=new Date(k+"T12:00:00");return `<div class="row"><div><b>${d.toLocaleDateString("pt-BR")}</b><div class="small">Trabalhado ${fmtMin(c.w)} • Jornada ${fmtMin(c.target)}</div></div><span class="tag">${c.extra?"+":c.deficit?"-":""}${fmtMin(c.extra||c.deficit)}</span></div>`}).join(""):"<div class='small'>Nenhum registro ainda.</div>";
}
function renderMoney(){
 let c=calc(dateKey()), hour=(Number(settings.salary)||0)/(Number(settings.divisor)||220), val=c.extra*hour*(1+Number(settings.extraPct||0)/100);
 $("money").textContent=`Hora base: R$ ${hour.toFixed(2)} • Hora extra de hoje: R$ ${val.toFixed(2)}`;
}
$("saveSettings").onclick=()=>{settings.salary=Number($("salary").value)||0;settings.extraPct=Number($("extraPct").value)||0;settings.divisor=Number($("divisor").value)||220;localStorage.setItem(SET,JSON.stringify(settings));render()};
$("salary").value=settings.salary;$("extraPct").value=settings.extraPct;$("divisor").value=settings.divisor;
$("clear").onclick=()=>{if(confirm("Apagar todos os registros?")){data={};save();render()}};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");["home","history","settings"].forEach(p=>$(p).classList.toggle("hidden",p!==b.dataset.page))});
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
setInterval(render,1000);render();